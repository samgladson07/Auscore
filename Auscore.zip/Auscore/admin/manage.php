<?php
$action = $_POST["action"];
    $usrname = $_POST["username"];
    $passwrd = $_POST["passwrd"];
function login() {
    global $usrname, $passwrd;
    $servername = "localhost";
$username = "root";
$password = "";
$dbname = "auscore";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM admin";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    if ($row["username"] == $usrname && $row["passwrd"] == $passwrd) {
        echo "
        <script>
        window.location.href='dashboard.php';
        </script>
        ";
    }
  }
} else {
  echo "0 results";
}
$conn->close();
}

if ($action == "0") {
    login();
} else {
    echo "Damn";
}
?>