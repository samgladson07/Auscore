
 <!DOCTYPE html>
<html>
    <head>
        <title>ADMIN LOGIN PANEL</title>
    </head>
    <style>
        body {
            background-image: url("https://cdn.pixabay.com/photo/2023/09/11/06/03/building-8246151_1280.jpg");
            display: flex;
            text-align: center;
            justify-content: center;
            align-items: center;
        }
        .transparentbox {
            background-color: rgba(0, 0, 0, 0.5); 
            color: white;
            text-align: center;
            align-items: center;
            border-radius: 10px;
            padding-left: 80px;
            padding-right: 80px;
            padding-top: 40px;
            padding-bottom: 200px;
            font-family: "Lucida Console", "Courier New", monospace;
        }
        .form123 {
            border-radius: 20px;
            padding-top: 20px;
            padding-bottom: 20px;
            padding-right: 50px;
            padding-left: 50px;
            align-items: left;
        }
        .myBtn {
            background-color: #00ffff;
            color: black;
            cursor: pointer;
            padding-left: 50px;
            padding-right: 50px;
            padding-top: 20px;
            padding-bottom: 20px;
            font-weight: bold;
            border-radius: 5px;
            border: none;
            box-shadow: 0 0 10px #00ffff, 0 0 20px #00ffff;
            transition-duration: 0.4s;
        }
        .myBtn:hover {
            background-color: white;
        }

    </style>
    <script>
        function Authendication() {
            alert("LOGIN SUCCESS");
        }
    </script>
    <body>
        <div class="transparentbox">
            <h1>ADMIN LOGIN PANEL</h1>
            <br><br>
            <form action="manage.php" method="post">
                    <legend>USERNAME</legend>
                    <input type="text" name="username" class="form123" placeholder="Enter Username">
                    <br><br><br><br>
                    <legend>PASSWORD</legend>
                    <input type="password" name="passwrd" class="form123" placeholder="Enter Password">
                    <input type="hidden" name="action" value="0">
                    <br><br><br>
                    <button class="myBtn" type="submit">  LOGIN
</button>
            </form>
            
        </div>
    </body>
</html>