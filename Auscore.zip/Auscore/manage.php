<?php

$action = $_POST["action"];
$name = $_POST["name"];
$phone = $_POST["phone"];
$email = $_POST["email"];
$message = $_POST["message"];

function contact() {
    global $name, $phone, $email, $message;
    $servername = "localhost";
$username = "root";
$password = "";
$dbname = "auscore";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO contact (name, phone, email, message)
VALUES ('$name', '$phone', '$email','$message')";

if ($conn->query($sql) === TRUE) {
  //echo "New record created successfully";
  echo "
  <script>
  alert('Your message submitted successfully');
  window.location.href='index.html';
  </script>
  ";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
}

if ($action == "0") {
    contact();
}
?>